public interface IntAlumno1 {
    void mostrarCurso();
}
