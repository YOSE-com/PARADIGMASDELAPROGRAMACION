public class HelloWord {
    public static void main(String[] args) {
        System.out.println("HELLO WORLD");
        System.out.println("yosss");
    }
}
